# AA式素数確定 vs Strong Baseline — Round 55: Analytic Tail Collapse

## Exact shortcut

`o > max(P)` なら全targetで `p mod o=p`。したがってCollision=0かつzero-anchor hit=0。
よってこのorder tail全体は、targetごとのsignature計算をせず1 finite behavior classへ畳める。

- q cap: **262,143**
- global exact-order classes: **21519**
- timingは単回の方向確認。class集合と最終Select結果はexact assertionで照合。

## C1_P_le_521

- targets: **98**, max(P): **521**
- exact-order classes: **21519**
- `o<=max(P)`: **299**
- analytic tail `o>max(P)`: **21220** (**98.61%**)
- final finite behavior classes: **271**
- selected exact match: **{'q': 523, 'order': 522, 'phi': 0, 'entropy': 6.614709844115218}**

- naive finite prepare: **0.296210s**
- analytic-tail prepare: **0.005690s**
- prepare reduction: **52.06x**
- strong exact-order Select: **0.513363s**
- analytic cold prepare+Select: **0.008739s**
- cold speedup: **58.74x**

## C2_P_523_1543

- targets: **145**, max(P): **1543**
- exact-order classes: **21519**
- `o<=max(P)`: **770**
- analytic tail `o>max(P)`: **20749** (**96.42%**)
- final finite behavior classes: **404**
- selected exact match: **{'q': 1019, 'order': 1018, 'phi': 0, 'entropy': 7.179909090014958}**

- naive finite prepare: **0.445557s**
- analytic-tail prepare: **0.017507s**
- prepare reduction: **25.45x**
- strong exact-order Select: **0.733773s**
- analytic cold prepare+Select: **0.024926s**
- cold speedup: **29.44x**

## C3_P_9217_12000

- targets: **296**, max(P): **11987**
- exact-order classes: **21519**
- `o<=max(P)`: **3914**
- analytic tail `o>max(P)`: **17605** (**81.81%**)
- final finite behavior classes: **906**
- selected exact match: **{'q': 2789, 'order': 2788, 'phi': 0, 'entropy': 8.209453365628912}**

- naive finite prepare: **1.002867s**
- analytic-tail prepare: **0.199081s**
- prepare reduction: **5.04x**
- strong exact-order Select: **1.683729s**
- analytic cold prepare+Select: **0.230757s**
- cold speedup: **7.30x**

## Meaning

巨大tail classは後から発見する必要すらない。Current Finiteの上限とsaved orderだけで、観測前に『このaxis群は既に全対象を分離済み』と判断できる。