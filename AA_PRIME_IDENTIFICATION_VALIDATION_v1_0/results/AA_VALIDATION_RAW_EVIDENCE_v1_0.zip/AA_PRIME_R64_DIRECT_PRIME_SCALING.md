# Round 64 — Direct Prime-Side Scaling

- Factor prefilter: **disabled**
- Exact proof observer: **Lucas–Lehmer**
- Backend: **GMP C + Mersenne reduction**

|p|M_p digits|result|LL seconds|
|---:|---:|---|---:|
|44497|13,395|PRIME|1.901608|
|86243|25,962|PRIME|9.642424|
|110503|33,265|PRIME|16.800519|
|132049|39,751|PRIME|25.651668|

## Result
The Prime-side branch is independent of factor discovery: AA may identify/address the target and invoke an exact primality proof observer directly.
All four positive controls were proven PRIME directly. The larger-exponent runs preserve the same logical path; only proof cost rises.

## Frontier implication
The current barrier at the 10^12–10^18 exponent frontier is computational proof cost, not a logical requirement to find a composite factor first.