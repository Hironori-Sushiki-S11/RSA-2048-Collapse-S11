# Round 59 — Deep Adaptive Representation Verification

## Goal

深さ2だけでなく、深さ3以上のAA軌跡を探し、各stepで Current Collision 密度から representation を自動選択しても、partition-onlyと同じaxis列・phi軌跡になるかを検証。

Rule: `edge_est = remaining_axes*|E_t|`, `partition_est = remaining_axes*m`; `edge_est < partition_est` ならedge、それ以外はpartition。

## Case 1: p=5001..8000, cap=31

- targets: **338**
- depth: **4**
- exact axis sequence: **[29, 23, 19, 11]**
- phi trajectory: **[4616, 371, 7, 0]**

|step|rep|edges before|axis|phi|checks|
|---:|---|---:|---:|---:|---:|
|1|partition|56953|29|4616|3380|
|2|partition|4616|23|371|3042|
|3|partition|371|19|7|2704|
|4|edge|7|11|0|49|

- partition-only median: **0.007535s**
- adaptive median: **0.007055s**
- wall speedup: **1.068x**
- primitive-check reduction: **1.253x**

## Case 2: p=5001..8000, cap=43

- targets: **338**
- depth: **4**
- exact axis sequence: **[37, 23, 29, 11]**
- phi trajectory: **[4616, 382, 7, 0]**

|step|rep|edges before|axis|phi|checks|
|---:|---|---:|---:|---:|---:|
|1|partition|56953|37|4616|4394|
|2|partition|4616|23|382|4056|
|3|partition|382|29|7|3718|
|4|edge|7|11|0|70|

- partition-only median: **0.008177s**
- adaptive median: **0.008057s**
- wall speedup: **1.015x**
- primitive-check reduction: **1.270x**

## Case 3: p=2..521, cap=31

- targets: **98**
- depth: **3**
- exact axis sequence: **[29, 23, 7]**
- phi trajectory: **[341, 14, 0]**

|step|rep|edges before|axis|phi|checks|
|---:|---|---:|---:|---:|---:|
|1|partition|4753|29|341|980|
|2|partition|341|23|14|882|
|3|edge|14|7|0|112|

- partition-only median: **0.001058s**
- adaptive median: **0.001009s**
- wall speedup: **1.049x**
- primitive-check reduction: **1.340x**

## Boundary

representation切替は結果を変えず、Current StateのCollision密度だけで計算表現を切り替える。
ただし閾値は単純なprimitive-count modelであり、次段階では実測単価を含むcost modelへ拡張する。