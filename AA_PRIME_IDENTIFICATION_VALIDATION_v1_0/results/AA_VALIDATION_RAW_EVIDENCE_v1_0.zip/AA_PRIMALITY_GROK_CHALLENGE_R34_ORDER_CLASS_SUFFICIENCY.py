#!/usr/bin/env python3
"""
Round 34 — Order-Class Sufficiency / Axis Realization Boundary.

For odd prime axes q:
  ord_q(2)=o.

On any finite Mersenne exponent corpus P:
  target-target collision partition under q depends only on o,
  because M_p == M_r mod q iff o | (p-r).

Zero-anchor hit set also depends only on o:
  M_p == 0 mod q iff o | p.

Therefore any q1,q2 with the same order are structurally indistinguishable
to the AA collision+anchor state. The finite corpus may collapse even
different orders into the same behavior class.

This round measures:
  - number of prime axes;
  - exact order classes;
  - finite target-target partition classes;
  - combined (partition + zero-anchor-hit) behavior classes;
  - certificate order classes relevant to prime exponents.
"""

from __future__ import annotations
import json,math
from collections import defaultdict,Counter
from pathlib import Path
import prime_goal_check as previous

AXIS_CAP=65535
CORPORA={
  'P_le_521':(2,521),
  'P_523_1543':(523,1543)
}


def sieve_primes(n):
    f=bytearray(b'\x01')*(n+1);f[:2]=b'\x00\x00'
    for p in range(2,math.isqrt(n)+1):
        if f[p]:f[p*p:n+1:p]=b'\x00'*((n-p*p)//p+1)
    return [i for i in range(2,n+1) if f[i]]

PRIME_AXES=[q for q in sieve_primes(AXIS_CAP) if q>2]


def factor_small(n):
    out={};d=2
    while d*d<=n:
        while n%d==0:out[d]=out.get(d,0)+1;n//=d
        d+=1 if d==2 else 2
    if n>1:out[n]=out.get(n,0)+1
    return out


def order2_prime(q):
    o=q-1
    for r in factor_small(o):
        while o%r==0 and pow(2,o//r,q)==1:o//=r
    return o

ORD={q:order2_prime(q) for q in PRIME_AXES}


def prime_exponents(lo,hi):
    axes=previous.prime_axes(math.isqrt(hi)+1)
    return [p for p in range(lo,hi+1) if all(p%d for d in axes if d*d<=p)]


def canonical_partition(ps,o):
    # Normalize residue groups to first-seen labels so only equality structure remains.
    mp={}
    nxt=0
    labels=[]
    for p in ps:
        r=p%o
        if r not in mp:
            mp[r]=nxt;nxt+=1
        labels.append(mp[r])
    return tuple(labels)


def anchor_signature(ps,o):
    # zero-anchor equality for odd prime axis q: ord_q(2) | p
    return tuple(i for i,p in enumerate(ps) if p%o==0)


def corpus(lo,hi):
    ps=prime_exponents(lo,hi)
    order_classes=defaultdict(list)
    partition_classes=defaultdict(list)
    behavior_classes=defaultdict(list)

    for q in PRIME_AXES:
        o=ORD[q]
        order_classes[o].append(q)
        part=canonical_partition(ps,o)
        anch=anchor_signature(ps,o)
        partition_classes[part].append(q)
        behavior_classes[(part,anch)].append(q)

    # Validate same-order axes have identical finite behavior.
    same_order_exact=True
    bad=[]
    for o,qs in order_classes.items():
        if len(qs)<2:continue
        ref=(canonical_partition(ps,o),anchor_signature(ps,o))
        for q in qs[1:]:
            got=(canonical_partition(ps,ORD[q]),anchor_signature(ps,ORD[q]))
            if got!=ref:
                same_order_exact=False
                bad.append({'order':o,'q':q})
                break

    # For each target prime exponent p, the certificate order class is exactly o=p.
    cert_classes={}
    for p in ps:
        qs=order_classes.get(p,[])
        proper=[]
        self_div=[]
        for q in qs:
            if p<=31 and q==(1<<p)-1:self_div.append(q)
            else:proper.append(q)
        if qs:
            cert_classes[str(p)]={
              'order':p,'axis_count':len(qs),
              'smallest_axis':min(qs),
              'proper_factor_axis_count':len(proper),
              'smallest_proper_factor_axis':None if not proper else min(proper),
              'self_divisor_axes':self_div
            }

    order_size_hist=Counter(len(v) for v in order_classes.values())
    partition_size_hist=Counter(len(v) for v in partition_classes.values())
    behavior_size_hist=Counter(len(v) for v in behavior_classes.values())

    return {
      'range':[lo,hi],'target_count':len(ps),
      'prime_axis_count':len(PRIME_AXES),
      'distinct_order_classes':len(order_classes),
      'finite_partition_classes':len(partition_classes),
      'combined_behavior_classes':len(behavior_classes),
      'same_order_behavior_exact':same_order_exact,
      'same_order_mismatches':bad,
      'order_class_size_histogram':dict(order_size_hist),
      'partition_class_size_histogram':dict(partition_size_hist),
      'behavior_class_size_histogram':dict(behavior_size_hist),
      'certificate_order_class_count':len(cert_classes),
      'certificate_order_classes':cert_classes,
      'targets_without_any_order_p_axis_under_cap':[
          p for p in ps if str(p) not in cert_classes
      ],
      'largest_order_classes':[
          {'order':o,'axis_count':len(qs),'smallest_axes':qs[:10]}
          for o,qs in sorted(order_classes.items(),
                             key=lambda kv:(-len(kv[1]),kv[0]))[:15]
      ],
      'largest_behavior_classes':[
          {'axis_count':len(qs),'smallest_axes':qs[:10],
           'orders':sorted({ORD[q] for q in qs})[:20]}
          for _,qs in sorted(behavior_classes.items(),
                             key=lambda kv:(-len(kv[1]),kv[1][0]))[:15]
      ]
    }


def main():
    out={'protocol':{
      'axis_family':'odd prime q<=65535',
      'structural_key':'ord_q(2)',
      'same_order_identity_equivalence':'same target-target collision partition',
      'same_order_anchor_equivalence':'same zero-anchor hit set',
      'finite_behavior_key':'(target-target partition, zero-anchor hit set)',
      'axis_realization_boundary':'AA state can select an order/behavior class; choosing a concrete q inside an exactly equivalent class needs an extra criterion such as smaller q/cost'
    },'corpora':{}}

    for name,(lo,hi) in CORPORA.items():
        out['corpora'][name]=corpus(lo,hi)

    Path('/mnt/data/AA_PRIMALITY_GROK_CHALLENGE_R34_RESULTS.json').write_text(
      json.dumps(out,indent=2),encoding='utf-8')

    for name,r in out['corpora'].items():
        print(name)
        print('targets',r['target_count'])
        print('axes',r['prime_axis_count'],
              'orders',r['distinct_order_classes'],
              'partitions',r['finite_partition_classes'],
              'behaviors',r['combined_behavior_classes'])
        print('same-order exact',r['same_order_behavior_exact'])
        print('certificate classes',r['certificate_order_class_count'])
        print('largest order',r['largest_order_classes'][:5])
        print('largest behavior',r['largest_behavior_classes'][:5])

if __name__=='__main__':main()
