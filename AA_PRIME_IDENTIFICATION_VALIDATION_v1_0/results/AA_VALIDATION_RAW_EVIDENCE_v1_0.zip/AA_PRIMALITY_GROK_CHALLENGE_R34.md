# AA式素数確定 vs Grok — Round 34: Order-Class Sufficiency (Corrected)

## 結論

prime axis `q` を個別に見る前に、Original AAのCurrent Finiteでは `ord_q(2)` が同じaxis群は完全に同一の構造作用を持つ。

`ord_q1(2)=ord_q2(2)` なら、
- target-target Collision partitionが同じ
- zero-anchor hit setが同じ

したがってCollision+anchor stateは、個々のqではなく **order class** をSelectできる。
同一class内の具体的q選択には、smallest q / costなど別のtie-breakが必要。

## P_le_521

- finite targets: **98**
- prime axes tested: **6541**
- distinct exact order classes: **6089**
- finite target-target partition classes: **226**
- partition + zero-anchor combined behavior classes: **243**
- same-order axes behavior exact: **True**
- zero-anchor order classes present under cap: **44**
- proper factor-certificate targets: **39**
- self-divisor `q=M_p` targets: **5**
- targets with no `ord_q(2)=p` axis under cap: **54**

### Largest exact order classes

|order|axis count|smallest axes|
|---:|---:|---|
|92|4|[277, 1013, 1657, 30269]|
|156|4|[313, 1249, 3121, 21841]|
|388|4|[389, 3881, 4657, 5821]|
|397|4|[2383, 6353, 50023, 53993]|
|1076|4|[2153, 3229, 5381, 8609]|
|1572|4|[12577, 14149, 33013, 39301]|
|2220|4|[2221, 4441, 6661, 31081]|
|29|3|[233, 1103, 2089]|

### Largest finite behavior classes

|axis count|orders represented|smallest axes|
|---:|---|---|
|6194|[295, 299, 303, 319, 323, 325, 333, 363, 375, 385, 391, 403, 411, 445, 451, 475, 483, 495, 513, 515]|[523, 541, 547, 557, 563, 587, 599, 607, 613, 619]|
|4|[92]|[277, 1013, 1657, 30269]|
|4|[156]|[313, 1249, 3121, 21841]|
|4|[388]|[389, 3881, 4657, 5821]|
|4|[201, 402]|[1609, 2011, 9649, 22111]|
|4|[397]|[2383, 6353, 50023, 53993]|
|3|[52]|[53, 157, 1613]|
|3|[51]|[103, 2143, 11119]|

## P_523_1543

- finite targets: **145**
- prime axes tested: **6541**
- distinct exact order classes: **6089**
- finite target-target partition classes: **311**
- partition + zero-anchor combined behavior classes: **357**
- same-order axes behavior exact: **True**
- zero-anchor order classes present under cap: **46**
- proper factor-certificate targets: **46**
- self-divisor `q=M_p` targets: **0**
- targets with no `ord_q(2)=p` axis under cap: **99**

### Largest exact order classes

|order|axis count|smallest axes|
|---:|---:|---|
|92|4|[277, 1013, 1657, 30269]|
|156|4|[313, 1249, 3121, 21841]|
|388|4|[389, 3881, 4657, 5821]|
|397|4|[2383, 6353, 50023, 53993]|
|1076|4|[2153, 3229, 5381, 8609]|
|1572|4|[12577, 14149, 33013, 39301]|
|2220|4|[2221, 4441, 6661, 31081]|
|29|3|[233, 1103, 2089]|

### Largest finite behavior classes

|axis count|orders represented|smallest axes|
|---:|---|---|
|5983|[497, 499, 513, 515, 519, 525, 531, 535, 537, 543, 545, 549, 551, 555, 575, 595, 605, 611, 615, 627]|[1019, 1031, 1039, 1061, 1063, 1087, 1091, 1109, 1117, 1123]|
|6|[51, 102]|[103, 307, 2143, 2857, 6529, 11119]|
|5|[397, 794]|[2383, 6353, 13499, 50023, 53993]|
|4|[29, 58]|[59, 233, 1103, 2089]|
|4|[83, 166]|[167, 499, 1163, 2657]|
|4|[113, 226]|[227, 3391, 23279, 48817]|
|4|[25, 50]|[251, 601, 1801, 4051]|
|4|[92]|[277, 1013, 1657, 30269]|

## 境界

AA Collision stateは『どのorder-classが必要か』までは構造的に扱える。
しかし同じorderを持つ複数のqはCurrent Finiteから見て完全同値なので、**Collisionだけからその中の唯一のqを選ぶことはできない。**

これは失敗ではなく、**Axis Select** と **Axis Realization** が別階層であることを示す。