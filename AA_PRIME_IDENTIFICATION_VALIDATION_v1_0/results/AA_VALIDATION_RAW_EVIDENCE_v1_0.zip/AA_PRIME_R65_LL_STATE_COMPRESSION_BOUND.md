# Round 65 — Prime-Proof State Compression Boundary

## Question
Can the final Lucas–Lehmer state be replaced by only small AA residue axes and still certify exact zero?

## Exact capacity of lcm(2..cap)
|cap|log2 LCM (bits)|
|---:|---:|
|26|34.640|
|64|89.934|
|128|183.123|
|256|362.828|
|512|742.697|
|1024|1478.858|
|4096|5924.620|
|65536|94448.051|

## Exact minimum cap needed for LCM capacity > M_p bit length
|p|minimum cap N with log2 lcm(2..N) > p|
|---:|---:|
|521|361|
|44497|30881|
|132049|91541|
|216091|149731|

## Explicit ambiguity witness
For p=44,497, L=lcm(2..512) has only **743 bits** while M_p has **44,497 bits**.
`L` is nonzero, smaller than M_p, but `L mod b = 0` for every b=2..512.
Therefore the projected observation vector of `S=0` and `S=L` is identical on all those axes.

Even lcm(2..4096) has only **5925 bits**, still far below 44,497 bits.

## Result
Small-axis projection alone cannot be an exact Prime certificate once its combined modulus is smaller than M_p.
This is not a failure of AA identity; it identifies a different Blind Spot: Prime proof requires an additional global/certificate-level invariant, not merely more small residue coordinates.

## Next Pick Up
Move from `state projection compression` to `proof-certificate compression`: search for exact global invariants/certificates that AA can select without reproducing the whole LL state.