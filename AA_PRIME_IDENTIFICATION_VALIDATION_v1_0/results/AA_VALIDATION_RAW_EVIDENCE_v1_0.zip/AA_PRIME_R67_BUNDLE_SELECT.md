# Round 67 — Cost-Selected Exact Prime-Proof Bundles

Measured modular-arithmetic cost is fit as `cost/update ~ B^alpha`, then Current Finite chooses bundle size before LL execution.
- fitted alpha: **1.362**

|case|targets|selected|actual best|hit?|selected speedup vs separate|best speedup vs separate|
|---|---:|---:|---:|---|---:|---:|
|F1_900s|8|1|1|YES|1.000x|1.000x|

### F1_900s
|bundle|predicted cost|actual median|updates|
|---:|---:|---:|---:|
|1|2.178197e-02|0.015960s|7428|
|2|2.808255e-02|0.026056s|3726|
|3|3.143322e-02|0.036403s|2807|
|4|3.637574e-02|0.048238s|1878|

|F2_1200s|6|1|1|YES|1.000x|1.000x|

### F2_1200s
|bundle|predicted cost|actual median|updates|
|---:|---:|---:|---:|
|1|3.092073e-02|0.025342s|7302|
|2|3.984465e-02|0.041782s|3661|
|3|4.620494e-02|0.060196s|2444|
|4|4.748281e-02|0.063784s|2450|

|F3_1600s|5|1|1|YES|1.000x|1.000x|

### F3_1600s
|bundle|predicted cost|actual median|updates|
|---:|---:|---:|---:|
|1|4.971035e-02|0.041881s|8039|
|2|6.109021e-02|0.068679s|4833|
|3|7.004513e-02|0.095865s|3224|
|4|7.575762e-02|0.125576s|3228|

## Result
All bundle choices remain exact because every packed execution is a ring projection of the same Lucas–Lehmer recurrence.
The experiment tests whether AA can choose proof representation from measured current arithmetic cost rather than using a fixed packing rule.