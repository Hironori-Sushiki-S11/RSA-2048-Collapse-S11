# Round 58 — Adaptive Representation: Dense Partition → Sparse Collision Edges

## Rule

`|E_t| >= m` なら全target partition、`|E_t| < m` なら current Collision edge と `k_t/q_t` survival lawへ切替。
これは内容ではなく **現在の状態密度に応じて表現方法を変える** 実験。

## C1_P_le_521

- targets: **98**
- exact axis sequence: **[509, 7]**
- phi trajectory: **[1, 0]**
|step|hybrid mode|edges before|axis|phi|primitive checks|
|---:|---|---:|---:|---:|---:|
|1|partition|4753|509|1|9408|
|2|edge|1|7|0|3|

- partition-only median: **0.003385s**
- hybrid median: **0.001899s**
- wall speedup: **1.78x**
- primitive-check reduction: **1.99x**

## C2_P_523_1543

- targets: **145**
- exact axis sequence: **[509, 7]**
- phi trajectory: **[13, 0]**
|step|hybrid mode|edges before|axis|phi|primitive checks|
|---:|---|---:|---:|---:|---:|
|1|partition|10440|509|13|13920|
|2|edge|13|7|0|15|

- partition-only median: **0.004758s**
- hybrid median: **0.002943s**
- wall speedup: **1.62x**
- primitive-check reduction: **1.99x**

## Boundary

このdense/sparse切替もgeneric algorithmとして実装可能であり、演算そのものを新規とはしない。
ただし `Current state` のCollision密度を見て、保存情報の使い方・表現そのものを切り替える、というAAのオーケストレーション原理を直接実装した形になっている。