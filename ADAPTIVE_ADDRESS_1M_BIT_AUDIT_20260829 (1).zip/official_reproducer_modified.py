#!/usr/bin/env python3
"""
IKERUSIKI Adaptive Address Scaling — public structural reproducer.

これは web_fetch で取得した ADAPTIVE_ADDRESS_SCALING_REPRODUCER.py の
GitHub blob表示内容を逐語転記したものです。bash_tool はネットワーク接続が
無効化されているため、リポジトリから直接ダウンロード(curl/git clone)する
ことはできませんでした。したがってこれは「公式スクリプトの直接実行」では
なく、「先に取得済みのソーステキストに基づくプロトコル等価再実行」です。

=== 元のコードからの変更点(このコメントブロック以外はすべて元のまま) ===
1. EXPECTED 辞書:
   - 元のコードは EXPECTED[(bit_size, seed)] に存在しないキーを渡すと
     KeyError で落ちる。今回のビット長(262144, 524288, 1048576)は
     EXPECTED に事前登録が無いため、これらのビット長に対して
     `.get()` を使い、存在しない場合は match=None(既存ベースラインなし)
     として扱うよう run_case() を変更した。
   - 32768/65536/131072 の既存 EXPECTED エントリは一切変更していない。
2. choose_cases() を使わず、BIT_SIZES と対象 seed を直接指定するループを
   main の代わりに用意した(コマンドライン引数処理は本検証で不要なため)。
3. 他の定数(CORPUS_SIZE=100, AXES=2..512, MAX_DEPTH=32)、
   generate_corpus, collision_potential, entropy_of_partition,
   refine_by_q, run_case の内部ロジックは元のまま変更していない。
=====================================================================
"""

from __future__ import annotations

import argparse
import math
import random
import time
from collections import defaultdict
from math import gcd, lcm

CORPUS_SIZE = 100
AXES = list(range(2, 513))
SEEDS = [20260812, 20260813, 20260814, 20260815, 20260816]
MAX_DEPTH = 32

EXPECTED = {
    (32768, 20260812): ("477|5", "4950->3->0"),
    (32768, 20260813): ("505|9", "4950->5->0"),
    (32768, 20260814): ("365|8", "4950->6->0"),
    (32768, 20260815): ("467|7", "4950->4->0"),
    (32768, 20260816): ("449|7", "4950->6->0"),
    (65536, 20260812): ("493|5", "4950->5->0"),
    (65536, 20260813): ("417|7", "4950->4->0"),
    (65536, 20260814): ("483|5", "4950->4->0"),
    (65536, 20260815): ("511|5", "4950->5->0"),
    (65536, 20260816): ("425|7", "4950->4->0"),
    (131072, 20260812): ("455|3", "4950->5->0"),
    (131072, 20260813): ("511|11", "4950->3->0"),
    (131072, 20260814): ("499|11", "4950->3->0"),
    (131072, 20260815): ("493|7", "4950->5->0"),
    (131072, 20260816): ("413|12", "4950->4->0"),
}


def generate_corpus(bit_size: int, corpus_size: int, seed: int) -> list[int]:
    rng = random.Random((seed << 20) ^ bit_size)
    values: set[int] = set()
    while len(values) < corpus_size:
        value = rng.getrandbits(bit_size)
        value |= 1 << (bit_size - 1)
        value |= 1
        values.add(value)
    return list(values)


def collision_potential(groups: list[list[int]]) -> int:
    return sum(len(g) * (len(g) - 1) // 2 for g in groups if len(g) > 1)


def entropy_of_partition(groups: list[list[int]], total: int) -> float:
    out = 0.0
    for group in groups:
        p = len(group) / total
        out -= p * math.log2(p)
    return out


def refine_by_q(
    values: list[int],
    groups: list[list[int]],
    L: int,
    q: int,
) -> list[list[int]]:
    if q == 1:
        return [list(group) for group in groups]
    out: list[list[int]] = []
    for group in groups:
        if len(group) <= 1:
            out.append(list(group))
            continue
        ref = values[group[0]]
        buckets: dict[int, list[int]] = defaultdict(list)
        for row_id in group:
            delta = values[row_id] - ref
            if delta % L != 0:
                raise AssertionError("current group violates LCM collision invariant")
            k_rel = delta // L
            buckets[k_rel % q].append(row_id)
        out.extend(buckets.values())
    return out


def run_case(bit_size: int, seed: int) -> dict[str, object]:
    values = generate_corpus(bit_size, CORPUS_SIZE, seed)
    groups = [list(range(len(values)))]
    remaining = set(AXES)
    selected: list[int] = []
    trajectory = [collision_potential(groups)]
    L = 1

    t0 = time.perf_counter()
    for _depth in range(1, MAX_DEPTH + 1):
        before = collision_potential(groups)
        if before == 0:
            break
        q_cache: dict[int, tuple[int, float, list[list[int]]]] = {}
        best = None
        for b in sorted(remaining):
            q = b // gcd(L, b)
            if q not in q_cache:
                candidate_groups = refine_by_q(values, groups, L, q)
                after = collision_potential(candidate_groups)
                ent = entropy_of_partition(candidate_groups, len(values))
                q_cache[q] = (after, ent, candidate_groups)
            after, ent, candidate_groups = q_cache[q]
            score = (before - after, ent, -b)
            row = (score, b, after, candidate_groups)
            if best is None or row[0] > best[0]:
                best = row
        if best is None:
            raise RuntimeError("no candidate axis available")
        _, b_star, after, groups_star = best
        selected.append(b_star)
        remaining.remove(b_star)
        groups = groups_star
        L = lcm(L, b_star)
        trajectory.append(after)
        if after == 0 or after == before:
            break
    elapsed = time.perf_counter() - t0

    axes_text = "|".join(map(str, selected))
    trajectory_text = "->".join(map(str, trajectory))

    # --- 変更点1(上記コメント参照): EXPECTEDに無いキーはmatch=Noneとする ---
    baseline = EXPECTED.get((bit_size, seed))
    if baseline is None:
        match = None  # 事前ベースラインなし。自己生成のTrue/Falseは付与しない。
    else:
        expected_axes, expected_trajectory = baseline
        match = axes_text == expected_axes and trajectory_text == expected_trajectory

    return {
        "bit_size": bit_size,
        "seed": seed,
        "selected_axes": axes_text,
        "trajectory": trajectory_text,
        "depth": len(selected),
        "collision_free": trajectory[-1] == 0,
        "elapsed_s": elapsed,
        "final_lcm": L,
        "match": match,
        "executed": True,
    }


if __name__ == "__main__":
    import sys
    import json

    # --- 変更点2: choose_cases()の代わりに、対象を直接指定 ---
    target_bits = [262144, 524288, 1048576]
    phase = sys.argv[1] if len(sys.argv) > 1 else "phase1"

    if phase == "phase1":
        seeds_to_run = [20260812]
    else:
        seeds_to_run = SEEDS

    print("IKERUSIKI Adaptive Address Scaling — Extended-Bit Reproducer Run")
    print(f"Phase: {phase}  |  Target bits: {target_bits}  |  Seeds: {seeds_to_run}")
    print("=" * 100)

    results = []
    for bit_size in target_bits:
        for seed in seeds_to_run:
            try:
                r = run_case(bit_size, seed)
                results.append(r)
                print(
                    f"{r['bit_size']:>8}-bit seed={r['seed']}: "
                    f"axes={r['selected_axes']:<10} "
                    f"phi={r['trajectory']:<14} "
                    f"depth={r['depth']} "
                    f"collision_free={r['collision_free']} "
                    f"final_LCM={r['final_lcm']} "
                    f"match={r['match']} "
                    f"time={r['elapsed_s']:.4f}s"
                )
            except Exception as e:
                err = {
                    "bit_size": bit_size,
                    "seed": seed,
                    "error": repr(e),
                    "executed": False,
                }
                results.append(err)
                print(f"{bit_size:>8}-bit seed={seed}: ERROR — {e!r}")

    print("=" * 100)
    with open(f"/home/claude/aa_test/raw_stdout_{phase}.json", "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"Saved raw results to raw_stdout_{phase}.json")
