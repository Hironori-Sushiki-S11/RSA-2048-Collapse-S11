# AA式素数確定 vs Strong Baseline — Round 54: Current-Finite Quotient Scaling

## 定義

既知数論baselineは `ord_q(2)` を保存し、同じexact orderを持つaxesを既に1 classへ統合済み。
AA追加分は、異なるorderでも現在の有限target集合上で同じ `(Collision partition, zero-anchor hits)` を作るものをさらに同値化する有限商。

- max q tested: **524,287**
- all-axis saved-order build: **0.118900s**

## Scaling

|q cap|corpus|targets|axes|exact-order classes|finite classes|order→finite|axis→finite|max orders/class|
|---:|---|---:|---:|---:|---:|---:|---:|---:|
|65,535|C1_P_le_521|98|6541|6089|243|25.06x|26.92x|5843|
|65,535|C2_P_523_1543|145|6541|6089|357|17.06x|18.32x|5673|
|65,535|C3_P_9217_12000|296|6541|6089|761|8.00x|8.60x|5225|
|131,071|C1_P_le_521|98|12250|11433|259|44.14x|47.30x|11169|
|131,071|C2_P_523_1543|145|12250|11433|389|29.39x|31.49x|10976|
|131,071|C3_P_9217_12000|296|12250|11433|846|13.51x|14.48x|10462|
|262,143|C1_P_le_521|98|22999|21519|271|79.41x|84.87x|21242|
|262,143|C2_P_523_1543|145|22999|21519|404|53.26x|56.93x|21041|
|262,143|C3_P_9217_12000|296|22999|21519|906|23.75x|25.39x|20467|
|524,287|C1_P_le_521|98|43389|40821|285|143.23x|152.24x|40530|
|524,287|C2_P_523_1543|145|43389|40821|423|96.50x|102.57x|40315|
|524,287|C3_P_9217_12000|296|43389|40821|953|42.83x|45.53x|39701|

## Reuse break-even (Round 53 timings)

|corpus|break-even Select calls|speedup @1|@10|@100|
|---|---:|---:|---:|---:|
|C1_P_le_521|1|1.68x|15.22x|79.05x|
|C2_P_523_1543|1|1.63x|14.31x|65.23x|
|C3_P_9217_12000|1|1.52x|11.95x|38.32x|

## 判定

axis上限を広げるほどglobal exact-order classは増えるが、Current Finiteで区別できるbehavior classはそれより遅く増えるかを観測する。
この差が残る限り、既知order cacheの上にもCurrent-Finite quotientという追加圧縮が存在する。