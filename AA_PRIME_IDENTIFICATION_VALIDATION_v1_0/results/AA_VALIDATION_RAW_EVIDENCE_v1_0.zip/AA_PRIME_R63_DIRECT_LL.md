# Round 63 — Direct Prime Path (No Factor Prefilter)

## Protocol
- Factor prefilter: **disabled**
- Pipeline: **AA identity → exact Lucas–Lehmer**
- LL backend: **GMP C**

## AA
- selected axes: **[23]**
- collision trajectory: **[0]**
- collision-free: **True**
- AA wall: **0.000296s**

## Exact direct determination

|p|AA address|LL result|LL seconds|
|---:|---|---|---:|
|44483|[11]|COMPOSITE|9.692140|
|44491|[12]|COMPOSITE|9.473913|
|44497|[3]|PRIME|8.563920|
|44501|[17]|COMPOSITE|9.124445|
|44507|[1]|COMPOSITE|9.424858|

- Prime: **1**
- Composite: **4**
- total LL compute: **46.279276s**

## Result
Factor discovery is not a prerequisite. The same direct exact observer returns PRIME for p=44497 and COMPOSITE for the neighboring prime-exponent targets.

AA provides the finite identity/address layer; Lucas–Lehmer is invoked directly as the Prime/Composite proof observer in this round.