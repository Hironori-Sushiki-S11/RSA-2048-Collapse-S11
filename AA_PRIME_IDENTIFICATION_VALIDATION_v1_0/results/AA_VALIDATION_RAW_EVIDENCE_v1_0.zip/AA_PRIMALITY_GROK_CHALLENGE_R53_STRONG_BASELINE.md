# AA式素数確定 vs Strong Known-Number-Theory Baseline — Round 53

## 比較の公平化

baseline側にも既知数論を十分与えた。`q-1` factorization、Legendreのmod8情報、`ord_q(2)` cache、さらに **同一exact orderを持つaxisのglobal collapse** まで許可。
AA側の追加は、**異なるexact orderでもCurrent Finite上で同じ identity partition + zero-anchor hit set を作るなら1 finite behavior classへ畳む**部分だけ。

- prime axes: **22999** (`q<=262,143`)
- global exact-order classes: **21519**
- common saved-order build: **0.063158s**

## C1_P_le_521

- targets: **98**
- exact-order classes (strong baseline): **21519**
- Current-Finite behavior classes (AA): **271**
- additional class compression: **79.41x**
- exact orders eliminated by finite merge: **21248**
- max different exact orders in one finite class: **21242**
- selected result exact match: **True**
- selected axis: **523**

|method|classes evaluated|select median|
|---|---:|---:|
|strong exact-order baseline|21519|0.491690s|
|AA finite classes (prepared)|271|0.003322s|

- warm Select speedup: **147.99x**
- finite-class preparation: **0.289753s**
- cold prepare+Select speedup vs strong baseline: **1.68x**
- state-cell reduction: **79.41x**

## C2_P_523_1543

- targets: **145**
- exact-order classes (strong baseline): **21519**
- Current-Finite behavior classes (AA): **404**
- additional class compression: **53.26x**
- exact orders eliminated by finite merge: **21115**
- max different exact orders in one finite class: **21041**
- selected result exact match: **True**
- selected axis: **1019**

|method|classes evaluated|select median|
|---|---:|---:|
|strong exact-order baseline|21519|0.735375s|
|AA finite classes (prepared)|404|0.006817s|

- warm Select speedup: **107.87x**
- finite-class preparation: **0.445619s**
- cold prepare+Select speedup vs strong baseline: **1.63x**
- state-cell reduction: **53.26x**

## C3_P_9217_12000

- targets: **296**
- exact-order classes (strong baseline): **21519**
- Current-Finite behavior classes (AA): **906**
- additional class compression: **23.75x**
- exact orders eliminated by finite merge: **20613**
- max different exact orders in one finite class: **20467**
- selected result exact match: **True**
- selected axis: **2789**

|method|classes evaluated|select median|
|---|---:|---:|
|strong exact-order baseline|21519|1.545646s|
|AA finite classes (prepared)|906|0.030445s|

- warm Select speedup: **50.77x**
- finite-class preparation: **0.988530s**
- cold prepare+Select speedup vs strong baseline: **1.52x**
- state-cell reduction: **23.75x**

## 判定

同一orderの統合はAAの成果として数えていない。比較対象はそこまで既知構造を使う。
残るAA側の差は、**Current Finiteが有限であるため、異なるglobal orderまで同一behaviorに見えることを利用した追加圧縮**。
cold one-shotではclass構築コストも含める。warm/repeated Selectではfinite class tableを再利用できる。