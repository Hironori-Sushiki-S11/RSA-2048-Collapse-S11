#!/usr/bin/env python3
"""
Round 33 — Dual Completion AA.

Separate two completion conditions:
  Identification completion:
    Phi_id = target-target collision pairs.
  Certificate completion:
    Psi_cert = targets still lacking a proper factor certificate
               within the current certified axis family.

Phase I:
  Original AA selects identity axes until Phi_id=0.

Phase II:
  Identity is frozen. Use prime sub-axes q<=65535 with ord_q(2)=p and q<M_p
  as zero-anchor certificate sub-axes.
  Bundle up to 16 sub-axes into one Composite Axis B=product(q_i).
  Each B is one packed observation and can certificate multiple targets via gcd.

This does NOT prove primality for targets left unresolved.
"""

from __future__ import annotations
import json,math
from pathlib import Path
import prime_goal_check as previous

AXIS_CAP=65535
BUNDLE=16
CORPORA={
  'P_le_521':(2,521),
  'P_523_1543':(523,1543)
}


def sieve_primes(n):
    f=bytearray(b'\x01')*(n+1);f[:2]=b'\x00\x00'
    for p in range(2,math.isqrt(n)+1):
        if f[p]:f[p*p:n+1:p]=b'\x00'*((n-p*p)//p+1)
    return [i for i in range(2,n+1) if f[i]]

PRIME_AXES=[q for q in sieve_primes(AXIS_CAP) if q>2]


def factor_small(n):
    out={};d=2
    while d*d<=n:
        while n%d==0:out[d]=out.get(d,0)+1;n//=d
        d+=1 if d==2 else 2
    if n>1:out[n]=out.get(n,0)+1
    return out


def order2_prime(q):
    o=q-1
    for r in factor_small(o):
        while o%r==0 and pow(2,o//r,q)==1:o//=r
    return o

ORD={q:order2_prime(q) for q in PRIME_AXES}


def prime_exponents(lo,hi):
    axes=previous.prime_axes(math.isqrt(hi)+1)
    out=[]
    for p in range(lo,hi+1):
        if all(p%d for d in axes if d*d<=p):out.append(p)
    return out


def proper_for_p(p,q):
    # q divides M_p when ord_q(2)=p. It is proper unless q=M_p.
    if ORD[q]!=p:return False
    if p<=31 and q==(1<<p)-1:return False
    return True


def identity_state(ps):
    # Reproduce the earlier exact identity choices over odd prime axes <=65535.
    # One axis already fully separates both current finite corpora.
    best=None
    for q in PRIME_AXES:
        o=ORD[q]
        classes={}
        for p in ps:classes[p%o]=classes.get(p%o,0)+1
        phi=sum(v*(v-1)//2 for v in classes.values())
        distinct=len(classes)
        key=(-phi,distinct,-q)
        if best is None or key>best['key']:
            best={'axis':q,'order':o,'phi':phi,'key':key}
    return {'selected_axes':[best['axis']],'O_id':best['order'],
            'Phi_id':best['phi']}


def first_proper_axis_by_target(ps):
    out={}
    for q in PRIME_AXES:
        p=ORD[q]
        if p in ps and p not in out and proper_for_p(p,q):
            out[p]=q
    return out


def make_bundles(mapping):
    items=sorted(mapping.items())  # (p,q)
    bundles=[]
    for i in range(0,len(items),BUNDLE):
        part=items[i:i+BUNDLE]
        B=1
        for p,q in part:B*=q
        bundles.append({'targets':[p for p,q in part],
                        'subaxes':[q for p,q in part],
                        'B':B,'bits':B.bit_length()})
    return bundles


def verify_bundle(bundle):
    rows=[]
    for p,q in zip(bundle['targets'],bundle['subaxes']):
        B=bundle['B']
        g=math.gcd((pow(2,p,B)-1)%B,B)
        # Because each target has exactly one selected q in this constructed bundle,
        # g should equal q unless another subaxis in the bundle also divides M_p.
        # For distinct prime exponents, that cannot happen.
        rows.append({'p':p,'expected_q':q,'direct_gcd':g,'exact':g==q})
    return rows


def audit(ps,certified):
    stats={'proper_factor_certificates':0,'ll_calls':0,
           'prime_count':0,'composite_count':0}
    for p in ps:
        if p in certified:
            q=certified[p]
            assert pow(2,p,q)==1
            stats['proper_factor_certificates']+=1
            stats['composite_count']+=1
        else:
            r=previous.lucas_lehmer(p)
            stats['ll_calls']+=1
            if r==0:stats['prime_count']+=1
            else:stats['composite_count']+=1
    return stats


def corpus(lo,hi):
    ps=prime_exponents(lo,hi)
    identity=identity_state(ps)
    mapping=first_proper_axis_by_target(set(ps))
    bundles=make_bundles(mapping)

    all_rows=[]
    for b in bundles:
        rows=verify_bundle(b)
        all_rows.extend(rows)
        b['verification']=rows
        b['all_exact']=all(r['exact'] for r in rows)

    O=identity['O_id']
    qclasses={}
    for p,q in mapping.items():
        order=ORD[q] # =p
        qt=order//math.gcd(O,order)
        qclasses.setdefault(str(qt),0)
        qclasses[str(qt)]+=1

    certified=set(mapping)
    psi_initial=len(ps)
    psi_after=len(ps)-len(certified)

    return {
      'range':[lo,hi],'target_count':len(ps),
      'identity':identity,
      'certificate_axis_cap':AXIS_CAP,
      'proper_factorable_target_count':len(mapping),
      'unresolved_after_axis_cap':psi_after,
      'Psi_cert_initial':psi_initial,
      'Psi_cert_after_bundles':psi_after,
      'bundle_size':BUNDLE,
      'bundle_count':len(bundles),
      'q_t_class_counts_relative_to_identity_O':qclasses,
      'bundles':bundles,
      'all_bundle_gcd_exact':all(b['all_exact'] for b in bundles),
      'audit':audit(ps,mapping)
    }


def main():
    out={'protocol':{
      'phase_I':'Original AA identity completion Phi_id=0',
      'phase_II':'zero-anchor proper-factor certificate coverage Psi_cert',
      'certificate_axis_family':'odd prime q<=65535 with ord_q(2)=p and q<M_p',
      'bundle_size':BUNDLE,
      'bundle_observation':'gcd(M_p mod B,B), B=product selected prime subaxes',
      'identity_uniqueness_is_primality':False,
      'unresolved_after_cap_is_prime':False
    },'corpora':{}}
    for name,(lo,hi) in CORPORA.items():out['corpora'][name]=corpus(lo,hi)
    Path('/mnt/data/AA_PRIMALITY_GROK_CHALLENGE_R33_RESULTS.json').write_text(
      json.dumps(out,indent=2),encoding='utf-8')
    for name,r in out['corpora'].items():
        print(name)
        print('identity',r['identity'])
        print('factorable',r['proper_factorable_target_count'],
              'unresolved',r['unresolved_after_axis_cap'],
              'bundles',r['bundle_count'])
        print('qclasses',r['q_t_class_counts_relative_to_identity_O'])
        print('exact',r['all_bundle_gcd_exact'])
        print('audit',r['audit'])

if __name__=='__main__':main()
