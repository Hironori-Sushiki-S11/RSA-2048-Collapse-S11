# Round 60 — Measured-Cost Representation Select

## Training calibration

- training: `p=2..521, cap=31`
- median partition cost/check: **1.650e-07s**
- median edge cost/check: **1.099e-07s**
- edge/partition unit-cost ratio: **0.666x**

Representation is selected by predicted wall cost, not by a fixed `|E|<m` rule.

## Fresh results

|range|cap|depth|sequence|partition|measured-cost|speedup|
|---|---:|---:|---|---:|---:|---:|
|523..1543|31|3|[29, 23, 11]|0.001552s|0.001462s|1.061x|

Trajectory `523..1543`, cap=31:

|step|rep|edges|axis|phi|pred partition|pred edge|
|---:|---|---:|---:|---:|---:|---:|
|1|partition|10440|29|812|2.392697e-04|1.147349e-02|
|2|partition|812|23|47|2.153428e-04|8.031442e-04|
|3|edge|47|11|0|1.914158e-04|4.132214e-05|

|1544..3072|31|3|[29, 23, 11]|0.002521s|0.002427s|1.039x|

Trajectory `1544..3072`, cap=31:

|step|rep|edges|axis|phi|pred partition|pred edge|
|---:|---|---:|---:|---:|---:|---:|
|1|partition|19110|29|1534|3.234267e-04|2.100176e-02|
|2|partition|1534|23|109|2.910840e-04|1.517270e-03|
|3|edge|109|11|0|2.587413e-04|9.583220e-05|

|3001..5000|31|3|[29, 23, 19]|0.003452s|0.003379s|1.022x|

Trajectory `3001..5000`, cap=31:

|step|rep|edges|axis|phi|pred partition|pred edge|
|---:|---|---:|---:|---:|---:|---:|
|1|partition|28441|29|2280|3.943825e-04|3.125646e-02|
|2|partition|2280|23|172|3.549443e-04|2.255134e-03|
|3|edge|172|19|0|3.155060e-04|1.512215e-04|

|5001..8000|31|4|[29, 23, 19, 11]|0.007194s|0.006747s|1.066x|

Trajectory `5001..8000`, cap=31:

|step|rep|edges|axis|phi|pred partition|pred edge|
|---:|---|---:|---:|---:|---:|---:|
|1|partition|56953|29|4616|5.577460e-04|6.259096e-02|
|2|partition|4616|23|371|5.019714e-04|4.565657e-03|
|3|edge|371|19|7|4.461968e-04|3.261812e-04|
|4|edge|7|11|0|3.904222e-04|5.385066e-06|

|5001..8000|43|4|[37, 23, 29, 11]|0.007565s|0.007236s|1.045x|

Trajectory `5001..8000`, cap=43:

|step|rep|edges|axis|phi|pred partition|pred edge|
|---:|---|---:|---:|---:|---:|---:|
|1|partition|56953|37|4616|7.250698e-04|8.136824e-02|
|2|partition|4616|23|382|6.692952e-04|6.087543e-03|
|3|edge|382|29|7|6.135206e-04|4.617969e-04|
|4|edge|7|11|0|5.577460e-04|7.692952e-06|

## Boundary

cost constants are learned only on the training corpus; fresh cases keep them fixed.
Axis sequence and Collision trajectory must exactly match partition-only.
このRoundは『現在の状態→予測費用→representation選択』を一段自動化した検証。