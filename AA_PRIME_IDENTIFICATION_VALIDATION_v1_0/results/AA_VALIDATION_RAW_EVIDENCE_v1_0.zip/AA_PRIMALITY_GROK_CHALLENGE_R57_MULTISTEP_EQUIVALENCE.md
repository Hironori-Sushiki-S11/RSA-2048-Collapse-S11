# AA vs Generic Multi-Step Select — Round 57

## 目的

一軸で終わらない既知ケース `p<=521, axes<=512` を使い、generic全target再partitionとAAのcurrent-collision edge state (`k_t/q_t`) を比較。

- targets: **98**
- candidate axes: **96** odd primes
- exact sequence: **[509, 7]**

## Trajectory

|step|axis|order|O|phi|generic target-mod evals|edge current collisions|edge checks|
|---:|---:|---:|---:|---:|---:|---:|---:|
|1|509|508|508|1|9408|4753|456288|
|2|7|3|1524|0|9310|1|95|

- generic median: **0.003271s**
- edge-state median: **0.045486s**
- wall ratio generic/edge: **0.072x**
- primitive-check ratio generic/edge: **0.041x**

## Interpretation

両者は同じaxis sequenceとCollision trajectoryを返した。
ただしedge法はstep 0では全pair Collisionを持つため高価で、Collisionが疎になった後に強くなる。
したがって実装上は `dense state→partition`, `sparse collision→k_t/q_t edge law` の切替が自然。
この切替もgeneric algorithmとして実装可能であり、演算自体をAA専有の新数理とはしない。