# AA式素数確定 vs Grok — Round 30: Mersenne Order-State Sufficiency

## 中核

Original AAのCollisionをMersenne生成構造へ写した。odd axis `b` では

`M_p ≡ M_q (mod b)  ⇔  ord_b(2) | (p-q)`

したがって選択済みaxis群に対し

`O_t = lcm(ord_b(2))`

と置けば、Current Collisionは `O_t | (p-q)` だけで完全に表現できる。

Collision edgeについて

`k_t(e)=|p-q|/O_t`

candidate axis `c` について

`q_t(c)=ord_c(2)/gcd(O_t,ord_c(2))`

とすると

**edge survives c ⇔ q_t(c) divides k_t(e)**

となる。これはAA Formal Basisのq/k survival lawをMersenne指数空間へ写した形。

## P_le_521 (2..521)

- targets: **98**
- selected odd axes: **[509, 7]**
- final order-state `O_t`: **1524**
- final collision pairs: **0**
- first-stateで全odd candidate検証: **254 axes**
- predicted survivors == direct survivors: **True**

|depth|axis|ord(axis)|O_t|phi|reduction|
|---:|---:|---:|---:|---:|---:|
|0|-|-|1|4753|0|
|1|509|508|508|1|4752|
|2|7|3|1524|0|1|

## P_523_1543 (523..1543)

- targets: **145**
- selected odd axes: **[509, 7]**
- final order-state `O_t`: **1524**
- final collision pairs: **0**
- first-stateで全odd candidate検証: **254 axes**
- predicted survivors == direct survivors: **True**

|depth|axis|ord(axis)|O_t|phi|reduction|
|---:|---:|---:|---:|---:|---:|
|0|-|-|1|10440|0|
|1|509|508|508|13|10427|
|2|7|3|1524|0|13|

## 判定

ここではfactorを予測していない。Collisionそのものから、Mersenne有限コーパスに固有のStructural Saved Informationとして指数差/order stateを抽出した。
次axisのCollision効果は巨大なMersenne本体を再観測せず、`O_t, k_t, q_t` だけで予測できる。

これは素数性証明ではない。次段階は、このorder-state Blind Spotとfactor/primality certificateの接続を検証すること。