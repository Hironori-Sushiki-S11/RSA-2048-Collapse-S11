# AA Frontier Round 61 — Trillion-Exponent Mersenne Corpus

## Fresh frontier
- 64 prime exponents near **10^12**
- p range: **1,000,000,000,039 .. 1,000,000,001,881**
- Approx decimal digits of each M_p: **301,029,995,676**
- vs GIMPS all-tested-once threshold 141,566,917: **7063.8x** in exponent
- vs current record-prime exponent 136,279,841: **7337.8x** in exponent

## AA identity
- selected axes: **[1019]**
- depth: **1**
- collision trajectory: **[0]**
- collision-free: **True**
- direct symbolic address uniqueness: **True**
- wall: **0.006586s**

## Exact composite certificates
- q=2kp+1, k<=**20,000**, q mod 8 in {1,7}
- candidate q after mod8: **524,725**
- prime q tested: **28,351**
- exact pow checks: **28,351**
- certified composite M_p: **12/64**
- unresolved: **52/64**
- factor-scan wall: **2.315581s**

|p|k|proper factor q|
|---:|---:|---:|
|1000000000169|304|608000000102753|
|1000000000211|4|8000000001689|
|1000000000271|328|656000000177777|
|1000000000561|683|1366000000766327|
|1000000000799|1|2000000001599|
|1000000000841|3396|6792000005712073|
|1000000000921|279|558000000513919|
|1000000000949|3991|7982000007574919|
|1000000001083|45|90000000097471|
|1000000001197|288|576000000689473|
|1000000001243|1|2000000002487|
|1000000001339|129|258000000345463|

## Interpretation
AA uniquely identifies the whole symbolic corpus without constructing the trillion-exponent Mersenne integers.
Any listed q exactly certifies that M_p is composite.
Unresolved targets remain unresolved; no prime label is assigned without an exact primality certificate.

## Next frontier condition
To claim prime identification beyond the current known-prime frontier, at least one unresolved target must receive an exact primality certificate, not merely survive factor search.