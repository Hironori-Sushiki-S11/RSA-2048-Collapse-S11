#!/usr/bin/env python3
"""
Round 30 — Mersenne-specific Structural Saved Information.

For M_p=2^p-1 and odd axis b:
  M_p == M_q (mod b)
iff
  2^p == 2^q (mod b)
iff
  ord_b(2) | (p-q).

For selected odd axes B_t define:
  O_t = lcm(ord_b(2): b in B_t)

Then:
  collision(p,q) iff O_t | (p-q).

For a current collision edge e=(p,q):
  k_t(e)=|p-q|/O_t

For candidate odd axis c:
  q_t(c)=ord_c(2)/gcd(O_t,ord_c(2))

Then:
  edge survives c iff q_t(c) | k_t(e).

This is the exact q/k survival law in exponent-order space.
"""

from __future__ import annotations
import json,math
from collections import Counter
from pathlib import Path
import prime_goal_check as previous

CORPORA={
  'P_le_521':(2,521),
  'P_523_1543':(523,1543)
}
AXIS_CAP=511
MAX_DEPTH=16


def prime_exponents(lo,hi):
    axes=previous.prime_axes(math.isqrt(hi)+1)
    out=[]
    for p in range(lo,hi+1):
        ok=True
        for d in axes:
            if d*d>p:break
            if p%d==0:ok=False;break
        if ok:out.append(p)
    return out


def multiplicative_order_2(b):
    assert b%2==1 and b>1
    x=2%b
    k=1
    while x!=1:
        x=(x*2)%b
        k+=1
        if k>2*b:
            raise RuntimeError(('order',b))
    return k


ORD={b:multiplicative_order_2(b) for b in range(3,AXIS_CAP+1,2)}


def phi_from_mod(ps,O):
    c=Counter(p%O for p in ps)
    return sum(v*(v-1)//2 for v in c.values())


def entropy_from_mod(ps,O):
    c=Counter(p%O for p in ps)
    n=len(ps);h=0.0
    for v in c.values():
        z=v/n;h-=z*math.log2(z)
    return h


def direct_phi(ps,axes):
    sigs=[]
    for p in ps:
        sigs.append(tuple((pow(2,p,b)-2)%b for b in axes))
    c=Counter(sigs)
    return sum(v*(v-1)//2 for v in c.values())


def direct_survivors(ps,axes,cand):
    # Current collision edges that remain collisions after cand.
    sigs=[tuple((pow(2,p,b)-2)%b for b in axes) for p in ps]
    out=[]
    for i in range(len(ps)):
        for j in range(i+1,len(ps)):
            if sigs[i]==sigs[j]:
                if (pow(2,ps[i],cand)-2)%cand == (pow(2,ps[j],cand)-2)%cand:
                    out.append((ps[i],ps[j]))
    return out


def predicted_survivors(ps,O,cand):
    oc=ORD[cand]
    qt=oc//math.gcd(O,oc)
    out=[]
    for i in range(len(ps)):
        for j in range(i+1,len(ps)):
            d=abs(ps[i]-ps[j])
            if d%O==0:
                kt=d//O
                if kt%qt==0:
                    out.append((ps[i],ps[j]))
    return out,qt


def select_order_state(ps):
    O=1;axes=[];traj=[]
    cur=phi_from_mod(ps,O)
    traj.append({'depth':0,'axis':None,'O':O,'phi':cur,'entropy':entropy_from_mod(ps,O)})
    validations=[]

    while cur>0 and len(axes)<MAX_DEPTH:
        best=None
        for b in range(3,AXIS_CAP+1,2):
            if b in axes:continue
            newO=math.lcm(O,ORD[b])
            ph=phi_from_mod(ps,newO)
            red=cur-ph
            ent=entropy_from_mod(ps,newO)
            key=(red,ent,-b)
            if best is None or key>best['key']:
                best={'axis':b,'newO':newO,'phi':ph,'red':red,'ent':ent,'key':key}
        if best is None or best['red']<=0:break

        b=best['axis']
        pred,qt=predicted_survivors(ps,O,b)
        direct=direct_survivors(ps,axes,b)
        validations.append({
            'depth_before':len(axes),'candidate':b,'O_before':O,
            'ord_candidate':ORD[b],'q_t':qt,
            'predicted_survivors':len(pred),'direct_survivors':len(direct),
            'exact_match':pred==direct
        })
        assert pred==direct

        axes.append(b);O=best['newO'];cur=best['phi']
        assert cur==direct_phi(ps,axes)
        traj.append({'depth':len(axes),'axis':b,'O':O,'phi':cur,
                     'reduction':best['red'],'entropy':best['ent'],
                     'ord_axis':ORD[b]})
    return {'selected_axes':axes,'depth':len(axes),'final_O':O,
            'final_phi':cur,'trajectory':traj,'validations':validations}


def global_validation(ps):
    # Validate q/k law for every odd candidate from the first nontrivial state
    # selected by the order-state algorithm.
    first=select_order_state(ps)
    if not first['selected_axes']:
        return {'tested':0,'all_match':True}
    b0=first['selected_axes'][0]
    O=ORD[b0]
    axes=[b0]
    tested=0
    mismatches=[]
    for c in range(3,AXIS_CAP+1,2):
        if c==b0:continue
        pred,qt=predicted_survivors(ps,O,c)
        direct=direct_survivors(ps,axes,c)
        tested+=1
        if pred!=direct:
            mismatches.append({'candidate':c,'q_t':qt,
                               'predicted':len(pred),'direct':len(direct)})
    return {'first_axis':b0,'O':O,'tested_candidates':tested,
            'all_match':len(mismatches)==0,'mismatches':mismatches}


def main():
    out={'protocol':{
      'target':'M_p=2^p-1',
      'odd_axis_theorem':'collision mod b iff ord_b(2) divides exponent difference',
      'state':'O_t=lcm multiplicative orders of selected axes',
      'edge_residual':'k_t=|p-q|/O_t',
      'candidate_quotient':'q_t=ord_c(2)/gcd(O_t,ord_c(2))',
      'survival_law':'edge survives iff q_t divides k_t',
      'axis_cap':AXIS_CAP,
      'selection':'max collision reduction -> max entropy -> smaller axis',
      'full_M_expansion':False
    },'corpora':{}}

    for name,(lo,hi) in CORPORA.items():
        ps=prime_exponents(lo,hi)
        sel=select_order_state(ps)
        val=global_validation(ps)
        out['corpora'][name]={'range':[lo,hi],'count':len(ps),
                              'selection':sel,'global_validation':val}

    Path('/mnt/data/AA_PRIMALITY_GROK_CHALLENGE_R30_RESULTS.json').write_text(
        json.dumps(out,indent=2),encoding='utf-8')
    for name,r in out['corpora'].items():
        print(name,'count',r['count'])
        print('axes',r['selection']['selected_axes'],'O',r['selection']['final_O'],
              'phi',r['selection']['final_phi'])
        print('traj',r['selection']['trajectory'])
        print('validations',r['selection']['validations'])
        print('global',r['global_validation'])

if __name__=='__main__':main()
