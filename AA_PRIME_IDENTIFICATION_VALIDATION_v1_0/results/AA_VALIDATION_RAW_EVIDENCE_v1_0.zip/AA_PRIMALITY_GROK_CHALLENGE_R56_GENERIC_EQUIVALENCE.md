# AA vs Fully Strengthened Generic Baseline — Round 56

## 結論

baseline側にも既知order cache、same-order collapse、finite-partition memoization、目的関数に基づくexact early-stopまで許した。
`phi=0` は最大Collision削減で、phi=0時のentropyは常にlog2(n)。q昇順で最初のphi=0はglobal optimum。
`ord_q(2)>max(P)` ならpartitionを作らずphi=0を確定できる。

- q cap: **131,071**
- exact-order classes: **11433**
- common saved-order build: **0.037092s**

## C1_P_le_521

- targets: **98**
- selected: **{'q': 523, 'order': 522, 'phi': 0, 'entropy': 6.614709844115218}**

|method|median|reps/classes|explicit partitions|
|---|---:|---:|---:|
|exhaustive strong|0.299692s|11433|all|
|generic finite memo exhaustive|0.127604s|242 unique|all reps scanned|
|objective-aware exact early stop|0.002072s|93|92|

- speedup vs exhaustive: **144.62x**
- speedup vs finite memo: **61.58x**
- examined fraction: **0.813%**
- partition fraction: **0.805%**

## C2_P_523_1543

- targets: **145**
- selected: **{'q': 1019, 'order': 1018, 'phi': 0, 'entropy': 7.179909090014958}**

|method|median|reps/classes|explicit partitions|
|---|---:|---:|---:|
|exhaustive strong|0.451770s|11433|all|
|generic finite memo exhaustive|0.216792s|332 unique|all reps scanned|
|objective-aware exact early stop|0.005081s|161|161|

- speedup vs exhaustive: **88.92x**
- speedup vs finite memo: **42.67x**
- examined fraction: **1.408%**
- partition fraction: **1.408%**

## C3_P_9217_12000

- targets: **296**
- selected: **{'q': 2789, 'order': 2788, 'phi': 0, 'entropy': 8.209453365628912}**

|method|median|reps/classes|explicit partitions|
|---|---:|---:|---:|
|exhaustive strong|0.955329s|11433|all|
|generic finite memo exhaustive|0.504659s|806 unique|all reps scanned|
|objective-aware exact early stop|0.028267s|376|376|

- speedup vs exhaustive: **33.80x**
- speedup vs finite memo: **17.85x**
- examined fraction: **3.289%**
- partition fraction: **3.289%**

## Boundary

このearly-stopはAA専用の数理演算ではない。保存orderとSelect目的を知るgeneric algorithmも同じ処理を実装できる。
したがって、このレベルまでbaselineを強化すると計算手順は実質同型。
AAの残る評価対象は、既知情報を `Current Finite→Collision→Blind Spot→Pick Up→Select→Update` として統一的に駆動する上位オーケストレーションと、その一般領域への転用性。